package com.example.QuickOrderJC.Model;

public enum TipoPedido {
    DELIVERY,
    RETIRO_EN_TIENDA,
    EXPRESS
}