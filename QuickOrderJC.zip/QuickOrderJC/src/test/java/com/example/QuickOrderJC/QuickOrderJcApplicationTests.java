package com.example.QuickOrderJC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickOrderJcApplicationTests {

	@Test
	void contextLoads() {
	}

}
